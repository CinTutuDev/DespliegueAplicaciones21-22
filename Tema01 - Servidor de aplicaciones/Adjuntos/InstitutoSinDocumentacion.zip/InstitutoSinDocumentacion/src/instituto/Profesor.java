package instituto;

public class Profesor extends Persona {

	private int salario;
	
	public Profesor(String nombre, int edad, int salario) {
		super(nombre, edad);
		this.salario = salario;
	}

	public int getSalario() {
		return salario;
	}

	public void setSalario(int salario) {
		this.salario = salario;
	}

	@Override
	public String toString() {
		return "Profesor [salario=" + salario + ", nombre=" + nombre + ", edad=" + edad + "]";
	}
}
