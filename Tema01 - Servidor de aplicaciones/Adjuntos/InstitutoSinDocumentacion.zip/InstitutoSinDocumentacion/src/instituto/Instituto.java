package instituto;

public class Instituto {
}
