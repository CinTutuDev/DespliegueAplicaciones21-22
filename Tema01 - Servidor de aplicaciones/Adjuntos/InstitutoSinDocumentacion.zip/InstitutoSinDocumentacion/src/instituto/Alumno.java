package instituto;

public class Alumno extends Persona{

	static int numExpedienteActual = 0;
	
	private int numExpediente;
	
	public Alumno(String nombre, int edad) {
		super(nombre, edad);
		Alumno.numExpedienteActual++;
		this.numExpediente = Alumno.numExpedienteActual;
	}

	public int getNumExpediente() {
		return numExpediente;
	}

	@Override
	public String toString() {
		return "Alumno [numExpediente=" + numExpediente + ", nombre=" + nombre + ", edad=" + edad + "]";
	}
}
